# test_samples/

This folder is where sample CIFAR-10 images live so you can quickly try
out the web app without hunting for your own test images.

It ships empty (real dataset images aren't bundled with the repo to keep
it lightweight) — populate it in one step:

```bash
python test_samples/generate_test_samples.py --count 20
```

This pulls 20 real images straight from the CIFAR-10 test split and saves
them here as PNGs, named `<index>_<true_label>.png` (e.g. `0007_cat.png`),
so you can visually confirm whether the model's prediction was correct.

Once populated, just drag any of these PNGs into the app at
`http://localhost:5000`.
