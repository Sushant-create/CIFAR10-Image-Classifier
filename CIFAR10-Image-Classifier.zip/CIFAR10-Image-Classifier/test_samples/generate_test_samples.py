"""
generate_test_samples.py
--------------------------
Pulls a handful of real images out of the CIFAR-10 test set and saves them
as PNGs in this folder, so you have ready-made images to drag into the web
app (main.py) without needing your own photos.

Usage (from the test_samples/ folder, or project root):
    python test_samples/generate_test_samples.py --count 20

Each file is named:  <index>_<true_label>.png
e.g. 0007_cat.png
"""

import argparse
import os

from tensorflow.keras import datasets
from PIL import Image

CLASS_NAMES = ['airplane', 'automobile', 'bird', 'cat', 'deer',
               'dog', 'frog', 'horse', 'ship', 'truck']


def main(count, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    print("Downloading/loading CIFAR-10 test split...")
    (_, _), (x_test, y_test) = datasets.cifar10.load_data()

    count = min(count, len(x_test))
    for i in range(count):
        label = CLASS_NAMES[int(y_test[i][0])]
        img = Image.fromarray(x_test[i])
        filename = f"{i:04d}_{label}.png"
        img.save(os.path.join(out_dir, filename))

    print(f"Saved {count} sample images to '{out_dir}/'")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--count", type=int, default=20,
                        help="Number of sample images to generate (default: 20)")
    parser.add_argument("--out_dir", type=str, default=os.path.dirname(__file__) or ".",
                        help="Output directory (default: this test_samples/ folder)")
    args = parser.parse_args()
    main(args.count, args.out_dir)
